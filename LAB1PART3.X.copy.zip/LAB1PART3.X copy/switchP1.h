/* 
 * File:   switch.h
 * Author: Garrett
 *
 * Created on September 19, 2015, 10:46 AM
 */

#ifndef SWITCH_H
#define	SWITCH_H

void initSW2();


#endif	/* SWITCH_H */

