/* 
 * File:   timer.h
 * Authors:
 *
 * Created on December 30, 2014, 8:07 PM
 */

#ifndef TIMER_H
#define	TIMER_H

void delayUs(unsigned int delay);

void initTimer2();



#endif	/* INITTIMER_H */

